<footer class="pageFooter">
<div class="lf w6c">
<div class="lu w2c first-child">
<h3>SEARCH</h3>
<?php get_search_form(); ?>
<!--/.lu .w2c--></div>
<div class="lu w1c vcard">
<h3>CONTACT</h3>
<span class="fn">XXXXXX</span><br />
<a class="email" href="mailto:XXXXXX@example.com">XXXXXX@example.com<br /></a>
<span class="tel">+00-0-0000-0000</span><br />
<a class="url" href="/path/">Link</a>
<!--/.lu .w1c--></div>
<div class="lu w1c vcard">
<h3>CONTACT</h3>
<span class="fn">XXXXXX</span><br />
<a class="email" href="mailto:XXXXXX@example.com">XXXXXX@example.com<br /></a>
<span class="tel">+00-0-0000-0000</span><br />
<a class="url" href="/path/">Link</a>
<!--/.lu .w1c--></div>
<div class="lu w1c vcard">
<h3>CONTACT</h3>
<span class="fn">XXXXXX</span><br />
<a class="email" href="mailto:XXXXXX@example.com">XXXXXX@example.com<br /></a>
<span class="tel">+00-0-0000-0000</span><br />
<a class="url" href="/path/">Link</a>
<!--/.lu .w1c--></div>
<div class="lu w1c">
<h3>MEET ME ON</h3>
<ul>
<li><a href="http://twitter.com/XXXXXX"><img src="<?php bloginfo('template_url'); ?>/img/footer_externalservice_twitter.gif" alt="twitter" /></a></li>
<li><a href="http://www.flickr.com/photos/XXXXXX/"><img src="<?php bloginfo('template_url'); ?>/img/footer_externalservice_flickr.gif" alt="flickr" /></a></li>
<li><a href="http://webtrendmap.com/XXXXXX/"><img src="<?php bloginfo('template_url'); ?>/img/footer_externalservice_webtrendmap.gif" alt="webtrendmap" /></a></li>
</ul>
<!--/.lu .w1p--></div>
<!--/.lf .w6c--></div>
<div class="footerBottom">
<nav class="footerNav">
<ul>
<li><a href="<?php bloginfo('siteurl'); ?>/">HOME</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/XXXXXX/">XXXXXX</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/XXXXXX/">XXXXXX</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/XXXXXX/">XXXXXX</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/XXXXXX/">XXXXXX</a></li>
<li><a href="<?php bloginfo('siteurl'); ?>/XXXXXX/">XXXXXX</a></li>
</ul>
</nav>

<div class="copyright">&copy; My Website.</div>
<!-- /.footerBottom --></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>