editAreaLoader.load_syntax["diff"] = {
    'COMMENT_SINGLE' : {}, 
    'COMMENT_MULTI' : {}, 
    'QUOTEMARKS' : {}, 
    'KEYWORDS' : {
        'keywordgroup1': ["\\ No newline at end of file"]
}, 
    'OPERATORS' : [], 
    'DELIMITERS' : [ '(', ')', '[', ']', '{', '}' ], 
    'STYLES' : { 
        'COMMENTS' : '', 
        'QUOTESMARKS' : '', 
        'KEYWORDS' : { 
        'keywordgroup1': 'color: #aaaaaa;'    }, 
       'OPERATORS' : '', 
        'DELIMITERS' : '' 
    } 
}; 
