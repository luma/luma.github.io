editAreaLoader.load_syntax["list.txt"] = {
    'COMMENT_SINGLE' : , 
    'COMMENT_MULTI' : , 
    'QUOTEMARKS' : , 
    'KEYWORDS' : {

}, 
    'OPERATORS' : , 
    'DELIMITERS' : [ '(', ')', '[', ']', '{', '}' ], 
    'STYLES' : { 
        'COMMENTS' : '', 
        'QUOTESMARKS' : '', 
        'KEYWORDS' : { 
    }, 
       'OPERATORS' : '', 
        'DELIMITERS' : '' 
    } 
}; 
