editAreaLoader.load_syntax["mxml"] = {
    'COMMENT_SINGLE' : {}, 
    'COMMENT_MULTI' : {"<!--": "-->"}, 
    'QUOTEMARKS' : {0: "\'", 1: "\""}, 
    'KEYWORDS' : {

}, 
    'OPERATORS' : [], 
    'DELIMITERS' : [ '(', ')', '[', ']', '{', '}' ], 
    'STYLES' : { 
        'COMMENTS' : '', 
        'QUOTESMARKS' : 'color: #ff0000;', 
        'KEYWORDS' : { 
    }, 
       'OPERATORS' : 'color: #66cc66;', 
        'DELIMITERS' : 'color: #66cc66;' 
    } 
}; 
