editAreaLoader.load_syntax["whitespace"] = {
    'COMMENT_SINGLE' : {}, 
    'COMMENT_MULTI' : {}, 
    'QUOTEMARKS' : {}, 
    'KEYWORDS' : {

}, 
    'OPERATORS' : [], 
    'DELIMITERS' : [ '(', ')', '[', ']', '{', '}' ], 
    'STYLES' : { 
        'COMMENTS' : '', 
        'QUOTESMARKS' : 'color: #ff0000;', 
        'KEYWORDS' : { 
    }, 
       'OPERATORS' : '', 
        'DELIMITERS' : '' 
    } 
}; 
