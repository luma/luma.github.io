﻿tinyMCE.addI18n("en.WPSynHighlight", {
	desc: 'WP-Synhighlight - syntax highlight source code', 
});