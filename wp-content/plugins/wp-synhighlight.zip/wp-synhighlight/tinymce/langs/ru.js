﻿tinyMCE.addI18n("ru.WPSynHighlight", {
	desc: 'WP-Synhighlight - отформатировать как исходный код', 
});